# eye/detection/__init__.py
"""
目标检测模块
"""
from eye.detection.object_detector import ObjectDetector

__all__ = ["ObjectDetector"]