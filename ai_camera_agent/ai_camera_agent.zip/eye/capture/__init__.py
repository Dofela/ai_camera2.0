# eye/capture/__init__.py
"""
视频采集模块
"""
from eye.capture.video_capture import VideoCapture
from eye.capture.frame_buffer import FrameBuffer

__all__ = ["VideoCapture", "FrameBuffer"]