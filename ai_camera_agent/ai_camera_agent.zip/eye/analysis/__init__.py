# eye/analysis/__init__.py
"""
场景分析模块
"""
from eye.analysis.scene_analyzer import SceneAnalyzer

__all__ = ["SceneAnalyzer"]