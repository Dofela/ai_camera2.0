# eye/__init__.py
"""
Eye 模块 - 感知层

负责所有感知相关的工作：
- 视频采集
- 目标检测
- 状态过滤
- 场景分析
- 感知记忆
"""
from eye.eye_core import EyeCore
from agent.types import PerceptionResult, DetectionResult, AnalysisResult

__all__ = [
    "EyeCore",
    "PerceptionResult",
    "DetectionResult",
    "AnalysisResult"
]